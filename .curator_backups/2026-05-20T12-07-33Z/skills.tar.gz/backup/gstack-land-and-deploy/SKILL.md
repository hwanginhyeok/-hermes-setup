---
name: gstack-land-and-deploy
description: |
  Land and deploy workflow. Merges the PR, waits for CI and deploy, verifies production health via canary checks. Takes over after /ship creates the PR. Use when: "merge", "land", "deploy", "merge and v
  (gstack - auto-synced)
category: gstack
---

# gstack-land-and-deploy

Load full skill: skill_view(name='gstack-land-and-deploy')

Source: ~/.claude/skills/gstack/land-and-deploy/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
