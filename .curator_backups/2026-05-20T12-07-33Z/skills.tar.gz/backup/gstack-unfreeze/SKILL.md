---
name: gstack-unfreeze
description: |
  Clear the freeze boundary set by /freeze, allowing edits to all directories again. Use when you want to widen edit scope without ending the session. Use when asked to "unfreeze", "unlock edits", "remo
  (gstack - auto-synced)
category: gstack
---

# gstack-unfreeze

Load full skill: skill_view(name='gstack-unfreeze')

Source: ~/.claude/skills/gstack/unfreeze/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
