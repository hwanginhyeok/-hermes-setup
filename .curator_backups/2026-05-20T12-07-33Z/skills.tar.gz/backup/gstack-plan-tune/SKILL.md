---
name: gstack-plan-tune
description: |
  Self-tuning question sensitivity + developer psychographic for gstack (v1: observational). Review which AskUserQuestion prompts fire across gstack skills, set per-question preferences (never-ask / alw
  (gstack - auto-synced)
category: gstack
---

# gstack-plan-tune

Load full skill: skill_view(name='gstack-plan-tune')

Source: ~/.claude/skills/gstack/plan-tune/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
