---
name: gstack-health
description: |
  Code quality dashboard. Wraps existing project tools (type checker, linter, test runner, dead code detector, shell linter), computes a weighted composite 0-10 score, and tracks trends over time. Use w
  (gstack - auto-synced)
category: gstack
---

# gstack-health

Load full skill: skill_view(name='gstack-health')

Source: ~/.claude/skills/gstack/health/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
