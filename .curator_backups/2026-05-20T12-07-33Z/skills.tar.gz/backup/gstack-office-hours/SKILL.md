---
name: gstack-office-hours
description: |
  YC Office Hours — two modes. Startup mode: six forcing questions that expose demand reality, status quo, desperate specificity, narrowest wedge, observation, and future-fit. Builder mode: design think
  (gstack - auto-synced)
category: gstack
---

# gstack-office-hours

Load full skill: skill_view(name='gstack-office-hours')

Source: ~/.claude/skills/gstack/office-hours/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
