---
name: gstack-benchmark-models
description: |
  Cross-model benchmark for gstack skills. Runs the same prompt through Claude, GPT (via Codex CLI), and Gemini side-by-side — compares latency, tokens, cost, and optionally quality via LLM judge. Answe
  (gstack - auto-synced)
category: gstack
---

# gstack-benchmark-models

Load full skill: skill_view(name='gstack-benchmark-models')

Source: ~/.claude/skills/gstack/benchmark-models/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
