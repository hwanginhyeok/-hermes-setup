---
name: gstack-gstack-upgrade
description: |
  Upgrade gstack to the latest version. Detects global vs vendored install, runs the upgrade, and shows what's new. Use when asked to "upgrade gstack", "update gstack", or "get latest version". Voice tr
  (gstack - auto-synced)
category: gstack
---

# gstack-gstack-upgrade

Load full skill: skill_view(name='gstack-gstack-upgrade')

Source: ~/.claude/skills/gstack/gstack-upgrade/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
