---
name: gstack-review
description: |
  Pre-landing PR review. Analyzes diff against the base branch for SQL safety, LLM trust boundary violations, conditional side effects, and other structural issues. Use when asked to "review this PR", "
  (gstack - auto-synced)
category: gstack
---

# gstack-review

Load full skill: skill_view(name='gstack-review')

Source: ~/.claude/skills/gstack/review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
