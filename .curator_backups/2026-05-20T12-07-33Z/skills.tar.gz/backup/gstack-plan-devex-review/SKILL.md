---
name: gstack-plan-devex-review
description: |
  Interactive developer experience plan review. Explores developer personas, benchmarks against competitors, designs magical moments, and traces friction points before scoring. Three modes: DX EXPANSION
  (gstack - auto-synced)
category: gstack
---

# gstack-plan-devex-review

Load full skill: skill_view(name='gstack-plan-devex-review')

Source: ~/.claude/skills/gstack/plan-devex-review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
