---
name: gstack-context-save
description: |
  Save working context. Captures git state, decisions made, and remaining work so any future session can pick up without losing a beat. Use when asked to "save progress", "save state", "context save", o
  (gstack - auto-synced)
category: gstack
---

# gstack-context-save

Load full skill: skill_view(name='gstack-context-save')

Source: ~/.claude/skills/gstack/context-save/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
