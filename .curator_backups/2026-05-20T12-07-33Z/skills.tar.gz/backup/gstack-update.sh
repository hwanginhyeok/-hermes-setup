#!/bin/bash
# gstack 업데이트 스크립트
# 사용: bash ~/.hermes/skills/gstack-update.sh
set -e

GSTACK_DIR="$HOME/.claude/skills/gstack"

echo "=== gstack 업데이트 ==="
cd "$GSTACK_DIR"

OLD_VER=$(cat VERSION)
git pull origin main 2>&1 | tail -3
NEW_VER=$(cat VERSION)

echo ""
echo "버전: $OLD_VER -> $NEW_VER"
echo ""

# 변경된 스킬 목록
CHANGED=$(git diff --name-only HEAD@{1} HEAD -- '*/SKILL.md' 2>/dev/null | sed 's|/SKILL.md||' | head -20)
if [ -n "$CHANGED" ]; then
    echo "변경된 스킬:"
    echo "$CHANGED" | while read line; do echo "  - $line"; done
else
    echo "스킬 변경 없음 (빌드/테스트만 업데이트)"
fi

echo ""
echo "완료. Hermes는 references/gstack-original.md 심볼릭으로 자동 연결됨"
