---
name: gstack-design-review
description: |
  Designer's eye QA: finds visual inconsistency, spacing issues, hierarchy problems, AI slop patterns, and slow interactions — then fixes them. Iteratively fixes issues in source code, committing each f
  (gstack - auto-synced)
category: gstack
---

# gstack-design-review

Load full skill: skill_view(name='gstack-design-review')

Source: ~/.claude/skills/gstack/design-review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
