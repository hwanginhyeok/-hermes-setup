---
name: gstack-ship
description: |
  Ship workflow: detect + merge base branch, run tests, review diff, bump VERSION, update CHANGELOG, commit, push, create PR. Use when asked to "ship", "deploy", "push to main", "create a PR", "merge an
  (gstack - auto-synced)
category: gstack
---

# gstack-ship

Load full skill: skill_view(name='gstack-ship')

Source: ~/.claude/skills/gstack/ship/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
