---
name: gstack-careful
description: |
  Safety guardrails for destructive commands. Warns before rm -rf, DROP TABLE, force-push, git reset --hard, kubectl delete, and similar destructive operations. User can override each warning. Use when 
  (gstack - auto-synced)
category: gstack
---

# gstack-careful

Load full skill: skill_view(name='gstack-careful')

Source: ~/.claude/skills/gstack/careful/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
