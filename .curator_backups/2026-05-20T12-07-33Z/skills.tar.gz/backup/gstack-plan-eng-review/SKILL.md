---
name: gstack-plan-eng-review
description: |
  Eng manager-mode plan review. Lock in the execution plan — architecture, data flow, diagrams, edge cases, test coverage, performance. Walks through issues interactively with opinionated recommendation
  (gstack - auto-synced)
category: gstack
---

# gstack-plan-eng-review

Load full skill: skill_view(name='gstack-plan-eng-review')

Source: ~/.claude/skills/gstack/plan-eng-review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
