---
name: gstack-browse
description: |
  Fast headless browser for QA testing and site dogfooding. Navigate any URL, interact with elements, verify page state, diff before/after actions, take annotated screenshots, check responsive layouts, 
  (gstack - auto-synced)
category: gstack
---

# gstack-browse

Load full skill: skill_view(name='gstack-browse')

Source: ~/.claude/skills/gstack/browse/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
