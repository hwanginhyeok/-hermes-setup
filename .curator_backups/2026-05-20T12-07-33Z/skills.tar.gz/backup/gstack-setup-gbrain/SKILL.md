---
name: gstack-setup-gbrain
description: |
  Set up gbrain for this coding agent: install the CLI, initialize a local PGLite or Supabase brain, register MCP, capture per-remote trust policy. One command from zero to "gbrain is running, and this 
  (gstack - auto-synced)
category: gstack
---

# gstack-setup-gbrain

Load full skill: skill_view(name='gstack-setup-gbrain')

Source: ~/.claude/skills/gstack/setup-gbrain/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
