---
name: gstack-retro
description: |
  Weekly engineering retrospective. Analyzes commit history, work patterns, and code quality metrics with persistent history and trend tracking. Team-aware: breaks down per-person contributions with pra
  (gstack - auto-synced)
category: gstack
---

# gstack-retro

Load full skill: skill_view(name='gstack-retro')

Source: ~/.claude/skills/gstack/retro/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
