---
name: gstack-design-consultation
description: |
  Design consultation: understands your product, researches the landscape, proposes a complete design system (aesthetic, typography, color, layout, spacing, motion), and generates font+color preview pag
  (gstack - auto-synced)
category: gstack
---

# gstack-design-consultation

Load full skill: skill_view(name='gstack-design-consultation')

Source: ~/.claude/skills/gstack/design-consultation/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
