---
name: gstack-cso
description: |
  Chief Security Officer mode. Infrastructure-first security audit: secrets archaeology, dependency supply chain, CI/CD pipeline security, LLM/AI security, skill supply chain scanning, plus OWASP Top 10
  (gstack - auto-synced)
category: gstack
---

# gstack-cso

Load full skill: skill_view(name='gstack-cso')

Source: ~/.claude/skills/gstack/cso/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
