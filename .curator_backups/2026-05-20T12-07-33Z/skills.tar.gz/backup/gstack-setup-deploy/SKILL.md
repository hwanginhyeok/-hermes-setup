---
name: gstack-setup-deploy
description: |
  Configure deployment settings for /land-and-deploy. Detects your deploy platform (Fly.io, Render, Vercel, Netlify, Heroku, GitHub Actions, custom), production URL, health check endpoints, and deploy s
  (gstack - auto-synced)
category: gstack
---

# gstack-setup-deploy

Load full skill: skill_view(name='gstack-setup-deploy')

Source: ~/.claude/skills/gstack/setup-deploy/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
