---
name: gstack-scrape
description: |
  Pull data from a web page. First call on a new intent prototypes the flow via $B primitives and returns JSON. Subsequent calls on a matching intent route to a codified browser-skill and return in ~200
  (gstack - auto-synced)
category: gstack
---

# gstack-scrape

Load full skill: skill_view(name='gstack-scrape')

Source: ~/.claude/skills/gstack/scrape/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
