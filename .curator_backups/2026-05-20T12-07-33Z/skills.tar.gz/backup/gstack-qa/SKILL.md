---
name: gstack-qa
description: |
  Systematically QA test a web application and fix bugs found. Runs QA testing, then iteratively fixes bugs in source code, committing each fix atomically and re-verifying. Use when asked to "qa", "QA",
  (gstack - auto-synced)
category: gstack
---

# gstack-qa

Load full skill: skill_view(name='gstack-qa')

Source: ~/.claude/skills/gstack/qa/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
