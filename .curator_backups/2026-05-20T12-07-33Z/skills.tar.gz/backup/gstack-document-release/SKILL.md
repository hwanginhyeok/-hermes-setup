---
name: gstack-document-release
description: |
  Post-ship documentation update. Reads all project docs, cross-references the diff, updates README/ARCHITECTURE/CONTRIBUTING/CLAUDE.md to match what shipped, polishes CHANGELOG voice, cleans up TODOS, 
  (gstack - auto-synced)
category: gstack
---

# gstack-document-release

Load full skill: skill_view(name='gstack-document-release')

Source: ~/.claude/skills/gstack/document-release/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
