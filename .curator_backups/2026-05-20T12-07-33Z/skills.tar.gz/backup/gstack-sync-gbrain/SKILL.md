---
name: gstack-sync-gbrain
description: |
  Keep gbrain current with this repo's code and refresh agent search guidance in CLAUDE.md. Wraps the gstack-gbrain-sync orchestrator with state probing, native code-surface registration, capability che
  (gstack - auto-synced)
category: gstack
---

# gstack-sync-gbrain

Load full skill: skill_view(name='gstack-sync-gbrain')

Source: ~/.claude/skills/gstack/sync-gbrain/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
