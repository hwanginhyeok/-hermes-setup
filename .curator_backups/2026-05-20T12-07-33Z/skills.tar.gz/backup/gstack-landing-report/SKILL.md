---
name: gstack-landing-report
description: |
  Read-only queue dashboard for workspace-aware ship. Shows which VERSION slots are currently claimed by open PRs, which sibling Conductor workspaces have WIP work likely to ship soon, and what slot /sh
  (gstack - auto-synced)
category: gstack
---

# gstack-landing-report

Load full skill: skill_view(name='gstack-landing-report')

Source: ~/.claude/skills/gstack/landing-report/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
