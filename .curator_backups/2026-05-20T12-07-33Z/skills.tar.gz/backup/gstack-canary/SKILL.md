---
name: gstack-canary
description: |
  Post-deploy canary monitoring. Watches the live app for console errors, performance regressions, and page failures using the browse daemon. Takes periodic screenshots, compares against pre-deploy base
  (gstack - auto-synced)
category: gstack
---

# gstack-canary

Load full skill: skill_view(name='gstack-canary')

Source: ~/.claude/skills/gstack/canary/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
