---
name: gstack-investigate
description: |
  Systematic debugging with root cause investigation. Four phases: investigate, analyze, hypothesize, implement. Iron Law: no fixes without root cause. Use when asked to "debug this", "fix this bug", "w
  (gstack - auto-synced)
category: gstack
---

# gstack-investigate

Load full skill: skill_view(name='gstack-investigate')

Source: ~/.claude/skills/gstack/investigate/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
