---
name: gstack-benchmark
description: |
  Performance regression detection using the browse daemon. Establishes baselines for page load times, Core Web Vitals, and resource sizes. Compares before/after on every PR. Tracks performance trends o
  (gstack - auto-synced)
category: gstack
---

# gstack-benchmark

Load full skill: skill_view(name='gstack-benchmark')

Source: ~/.claude/skills/gstack/benchmark/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
