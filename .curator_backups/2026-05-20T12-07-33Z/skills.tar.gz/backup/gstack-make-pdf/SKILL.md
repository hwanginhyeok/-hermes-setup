---
name: gstack-make-pdf
description: |
  Turn any markdown file into a publication-quality PDF. Proper 1in margins, intelligent page breaks, page numbers, cover pages, running headers, curly quotes and em dashes, clickable TOC, diagonal DRAF
  (gstack - auto-synced)
category: gstack
---

# gstack-make-pdf

Load full skill: skill_view(name='gstack-make-pdf')

Source: ~/.claude/skills/gstack/make-pdf/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
