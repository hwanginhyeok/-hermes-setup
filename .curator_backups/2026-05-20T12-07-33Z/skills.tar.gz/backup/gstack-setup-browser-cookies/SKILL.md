---
name: gstack-setup-browser-cookies
description: |
  Import cookies from your real Chromium browser into the headless browse session. Opens an interactive picker UI where you select which cookie domains to import. Use before QA testing authenticated pag
  (gstack - auto-synced)
category: gstack
---

# gstack-setup-browser-cookies

Load full skill: skill_view(name='gstack-setup-browser-cookies')

Source: ~/.claude/skills/gstack/setup-browser-cookies/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
