---
name: gstack-qa-only
description: |
  Report-only QA testing. Systematically tests a web application and produces a structured report with health score, screenshots, and repro steps — but never fixes anything. Use when asked to "just repo
  (gstack - auto-synced)
category: gstack
---

# gstack-qa-only

Load full skill: skill_view(name='gstack-qa-only')

Source: ~/.claude/skills/gstack/qa-only/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
