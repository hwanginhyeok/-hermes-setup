---
name: gstack-autoplan
description: |
  Auto-review pipeline — reads the full CEO, design, eng, and DX review skills from disk and runs them sequentially with auto-decisions using 6 decision principles. Surfaces taste decisions (close appro
  (gstack - auto-synced)
category: gstack
---

# gstack-autoplan

Load full skill: skill_view(name='gstack-autoplan')

Source: ~/.claude/skills/gstack/autoplan/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
