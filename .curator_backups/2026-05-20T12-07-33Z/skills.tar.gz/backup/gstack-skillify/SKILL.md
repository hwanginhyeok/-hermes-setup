---
name: gstack-skillify
description: |
  Codify the most recent successful /scrape flow into a permanent browser-skill on disk. Future /scrape calls with the same intent run the codified script in ~200ms instead of re-driving the page. Walks
  (gstack - auto-synced)
category: gstack
---

# gstack-skillify

Load full skill: skill_view(name='gstack-skillify')

Source: ~/.claude/skills/gstack/skillify/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
