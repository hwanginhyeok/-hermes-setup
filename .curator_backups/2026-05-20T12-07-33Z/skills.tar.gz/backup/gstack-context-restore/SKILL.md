---
name: gstack-context-restore
description: |
  Restore working context saved earlier by /context-save. Loads the most recent saved state (across all branches by default) so you can pick up where you left off — even across Conductor workspace hando
  (gstack - auto-synced)
category: gstack
---

# gstack-context-restore

Load full skill: skill_view(name='gstack-context-restore')

Source: ~/.claude/skills/gstack/context-restore/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
