---
name: gstack-plan-ceo-review
description: |
  CEO/founder-mode plan review. Rethink the problem, find the 10-star product, challenge premises, expand scope when it creates a better product. Four modes: SCOPE EXPANSION (dream big), SELECTIVE EXPAN
  (gstack - auto-synced)
category: gstack
---

# gstack-plan-ceo-review

Load full skill: skill_view(name='gstack-plan-ceo-review')

Source: ~/.claude/skills/gstack/plan-ceo-review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
