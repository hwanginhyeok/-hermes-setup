---
name: gstack-design-shotgun
description: |
  Design shotgun: generate multiple AI design variants, open a comparison board, collect structured feedback, and iterate. Standalone design exploration you can run anytime. Use when: "explore designs",
  (gstack - auto-synced)
category: gstack
---

# gstack-design-shotgun

Load full skill: skill_view(name='gstack-design-shotgun')

Source: ~/.claude/skills/gstack/design-shotgun/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
