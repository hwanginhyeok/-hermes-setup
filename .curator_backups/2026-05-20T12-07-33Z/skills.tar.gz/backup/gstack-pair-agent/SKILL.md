---
name: gstack-pair-agent
description: |
  Pair a remote AI agent with your browser. One command generates a setup key and prints instructions the other agent can follow to connect. Works with OpenClaw, Hermes, Codex, Cursor, or any agent that
  (gstack - auto-synced)
category: gstack
---

# gstack-pair-agent

Load full skill: skill_view(name='gstack-pair-agent')

Source: ~/.claude/skills/gstack/pair-agent/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
