---
name: gstack-codex
description: |
  OpenAI Codex CLI wrapper — three modes. Code review: independent diff review via codex review with pass/fail gate. Challenge: adversarial mode that tries to break your code. Consult: ask codex anythin
  (gstack - auto-synced)
category: gstack
---

# gstack-codex

Load full skill: skill_view(name='gstack-codex')

Source: ~/.claude/skills/gstack/codex/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
