---
name: gstack-guard
description: |
  Full safety mode: destructive command warnings + directory-scoped edits. Combines /careful (warns before rm -rf, DROP TABLE, force-push, etc.) with /freeze (blocks edits outside a specified directory)
  (gstack - auto-synced)
category: gstack
---

# gstack-guard

Load full skill: skill_view(name='gstack-guard')

Source: ~/.claude/skills/gstack/guard/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
