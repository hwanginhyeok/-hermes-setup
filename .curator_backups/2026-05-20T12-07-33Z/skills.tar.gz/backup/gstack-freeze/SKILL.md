---
name: gstack-freeze
description: |
  Restrict file edits to a specific directory for the session. Blocks Edit and Write outside the allowed path. Use when debugging to prevent accidentally "fixing" unrelated code, or when you want to sco
  (gstack - auto-synced)
category: gstack
---

# gstack-freeze

Load full skill: skill_view(name='gstack-freeze')

Source: ~/.claude/skills/gstack/freeze/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
