---
name: gstack-connect-chrome
description: |
  Launch GStack Browser — AI-controlled Chromium with the sidebar extension baked in. Opens a visible browser window where you can watch every action in real time. The sidebar shows a live activity feed
  (gstack - auto-synced)
category: gstack
---

# gstack-connect-chrome

Load full skill: skill_view(name='gstack-connect-chrome')

Source: ~/.claude/skills/gstack/connect-chrome/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
