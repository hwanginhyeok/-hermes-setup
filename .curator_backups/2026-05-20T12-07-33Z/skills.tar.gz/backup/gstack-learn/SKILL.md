---
name: gstack-learn
description: |
  Manage project learnings. Review, search, prune, and export what gstack has learned across sessions. Use when asked to "what have we learned", "show learnings", "prune stale learnings", or "export lea
  (gstack - auto-synced)
category: gstack
---

# gstack-learn

Load full skill: skill_view(name='gstack-learn')

Source: ~/.claude/skills/gstack/learn/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
