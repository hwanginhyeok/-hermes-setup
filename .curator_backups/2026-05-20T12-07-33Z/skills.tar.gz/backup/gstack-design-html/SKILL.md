---
name: gstack-design-html
description: |
  Design finalization: generates production-quality Pretext-native HTML/CSS. Works with approved mockups from /design-shotgun, CEO plans from /plan-ceo-review, design review context from /plan-design-re
  (gstack - auto-synced)
category: gstack
---

# gstack-design-html

Load full skill: skill_view(name='gstack-design-html')

Source: ~/.claude/skills/gstack/design-html/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
