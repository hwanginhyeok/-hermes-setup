---
name: gstack-devex-review
description: |
  Live developer experience audit. Uses the browse tool to actually TEST the developer experience: navigates docs, tries the getting started flow, times TTHW, screenshots error messages, evaluates CLI h
  (gstack - auto-synced)
category: gstack
---

# gstack-devex-review

Load full skill: skill_view(name='gstack-devex-review')

Source: ~/.claude/skills/gstack/devex-review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
