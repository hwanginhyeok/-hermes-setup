---
name: gstack-plan-design-review
description: |
  Designer's eye plan review — interactive, like CEO and Eng review. Rates each design dimension 0-10, explains what would make it a 10, then fixes the plan to get there. Works in plan mode. For live si
  (gstack - auto-synced)
category: gstack
---

# gstack-plan-design-review

Load full skill: skill_view(name='gstack-plan-design-review')

Source: ~/.claude/skills/gstack/plan-design-review/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
