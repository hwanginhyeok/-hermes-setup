---
name: gstack-open-gstack-browser
description: |
  Launch GStack Browser — AI-controlled Chromium with the sidebar extension baked in. Opens a visible browser window where you can watch every action in real time. The sidebar shows a live activity feed
  (gstack - auto-synced)
category: gstack
---

# gstack-open-gstack-browser

Load full skill: skill_view(name='gstack-open-gstack-browser')

Source: ~/.claude/skills/gstack/open-gstack-browser/SKILL.md
Update: cd ~/.claude/skills/gstack && git pull origin main
