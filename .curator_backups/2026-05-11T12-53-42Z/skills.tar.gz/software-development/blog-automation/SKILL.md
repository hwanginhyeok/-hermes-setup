---
name: blog-automation
description: "Blog automation systems: content generation, scheduling, publishing, and comment management across platforms (Naver Blog, WordPress, etc.)."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [blog, automation, publishing, content-generation, naver-blog]
    related_skills: [writing-plans, subagent-driven-development]
---

# Blog Automation

Automated blog operations: content planning, AI-powered writing, scheduling, publishing, and comment management. Covers full-stack automation from ideation to engagement.

## Use Cases

- **iCloud Photo → Blog**: Daily photo collection → AI analysis → content planning → auto-publishing
- **Comment Bots**: AI-powered comment generation, reply automation, engagement tracking
- **Multi-platform Publishing**: Single source → Naver Blog, WordPress, Ghost, Hugo, etc.
- **Content Workflows**: Ideation → Draft → Review → Publish → Promote
- **SNS Integration**: Auto-post to Telegram, Twitter/X, Instagram after blog publish

## Architecture Patterns

### Classic Naver Blog Automation (insung-blog project)

**Tech Stack:**
- Python 3.12+ with async/await
- Playwright for browser automation (headless/headed)
- Claude API (Vision + Text generation)
- FastAPI for webhook/API endpoints
- Supabase for control plane (settings, logs)
- SQLite for local DB (comments, runs)
- Next.js 14 for web dashboard
- systemd for service management
- Telegram for notifications

**Core Services:**
```
blog-api.service      → FastAPI server (port 8001)
blog-worker.service   → Command queue worker
```

**Workflow:**
1. **Photo Collection**: Playwright → iCloud.com → download latest photos
2. **Content Analysis**: Claude Vision → analyze photos → generate topics/tags/memo
3. **Draft Generation**: Claude API → generate blog post from plan
4. **Publishing**: Playwright → Naver Blog → post content with images
5. **Notification**: Telegram → notify user of draft/review/publish

**Key Modules:**
```
src/icloud/icloud_client.py     → iCloud photo download
src/content/photo_analyzer.py   → Vision-based content planning
src/content/draft_generator.py  → AI-powered writing
publisher_main.py               → Naver Blog publishing
api_server.py                   → FastAPI endpoints
src/utils/telegram_notifier.py  → Telegram notifications
command_worker.py               → Background task queue
```

### Multi-Platform Pattern

**When to Use:** Managing multiple blogs with shared content

```
┌─────────────┐
│   Source    │ (Photos, Notes, Ideas)
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Planner   │ (AI planning, topic selection)
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Generator  │ (AI writing, formatting)
└──────┬──────┘
       │
       ├─────────┬─────────┬─────────┐
       ▼         ▼         ▼         ▼
  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
  │ Naver  │ │Wordpress│ │ Ghost  │ │ Hugo   │
  │  Blog  │ │        │ │        │ │        │
  └────────┘ └────────┘ └────────┘ └────────┘
```

**Implementation:**
- Abstract `Publisher` interface with platform-specific implementations
- Unified content model (Markdown with frontmatter)
- Platform-specific formatters (HTML, MD, etc.)
- Unified scheduling (cron, webhooks, event-driven)

## Platform-Specific Integration

### Naver Blog

**Authentication:**
- Login cookies stored in `cookies/` directory
- Periodic cookie refresh required (2FA detection)
- Use `save_cookies.py` to refresh manually when login expires

**Publishing Flow:**
```python
# publisher_main.py pattern
from playwright.async_api import async_playwright

async def publish_post(title: str, content: str, images: List[str]):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        
        # 1. Load cookies
        await page.context.add_cookies(cookies)
        
        # 2. Navigate to blog write page
        await page.goto("https://blog.naver.com/post/write")
        
        # 3. Fill title and content
        await page.fill("#title", title)
        await page.fill("#content", content)
        
        # 4. Upload images (if any)
        for img in images:
            await page.set_input_files("#file-upload", img)
            await page.wait_for_timeout(1000)
        
        # 5. Publish
        await page.click("#publish-button")
        await page.wait_for_url("**/blog.naver.com/*")
        
        await browser.close()
```

**Selectors Change:** Naver Blog DOM changes frequently. Use `debug_publisher.py` to inspect current selectors before updating production code.

**Comments:**
- Comments require different auth (sometimes separate login)
- Comment selectors are different from post selectors
- Use `debug_comment_selector.py` for DOM analysis

### WordPress (Self-hosted)

**Approach:**
- REST API (preferred): `/wp-json/wp/v2/posts`
- XML-RPC (legacy, still used by Jetpack)
- Playwright (fallback for complex plugins)

```python
import requests

def publish_wordpress(site_url: str, title: str, content: str, api_token: str):
    url = f"{site_url}/wp-json/wp/v2/posts"
    headers = {"Authorization": f"Bearer {api_token}"}
    data = {
        "title": title,
        "content": content,
        "status": "publish"
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json()
```

### Ghost / Jekyll / Hugo

**Approach:**
- Git-based workflow: push markdown files → CI/CD → deploy
- Use frontmatter for metadata (title, tags, date, slug)

```markdown
---
title: "Post Title"
tags: ["tech", "tutorial"]
date: 2026-05-10
slug: post-title
---

Content here...
```

**Automation:**
```python
def create_hugo_post(content_dir: str, title: str, body: str, tags: List[str]):
    from datetime import datetime
    from pathlib import Path
    
    slug = title.lower().replace(" ", "-")
    date_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"{date_str}-{slug}.md"
    filepath = Path(content_dir) / filename
    
    frontmatter = f"""---
title: "{title}"
tags: {tags}
date: {date_str}
---

{body}
"""
    
    filepath.write_text(frontmatter)
    return filepath
```

## Content Generation Pipeline

### Photo-Driven Workflow (iCloud Example)

**Pattern:**
1. **Collect**: Fetch latest photos from source (iCloud, Google Photos, local folder)
2. **Analyze**: Vision AI → identify subjects, mood, composition → suggest topics
3. **Plan**: Generate title, topics, tags, memo, tone
4. **Draft**: AI writing with persona-specific voice
5. **Review**: Human approval via Telegram/Slack
6. **Publish**: Platform-specific posting

**Example Plan Structure:**
```json
{
    "title": "데스크탑 세팅 공유",
    "topics": ["하드웨어", "소프트웨어", "개발 환경"],
    "tags": ["tech", "setup", "dev-tools"],
    "memo": "개발자 친구들에게 공유하는 스타일, CLI 툴 위주로 설명",
    "tone": "friendly"
}
```

### Text-Only Workflow

**Pattern:**
1. **Ideation**: User provides keyword, topic, or inspiration
2. **Research**: Web search → gather context, quotes, examples
3. **Outline**: Generate structured outline with H1/H2/H3
4. **Draft**: Fill in sections with AI writing
5. **Optimize**: SEO, readability, tone adjustment
6. **Publish**: Platform-specific formatting and posting

## Comment Automation

### Comment Generation

**Pattern:**
```python
async def generate_comment(post: dict, persona: str = "helpful_expert") -> str:
    prompt = f"""
    블로그 글: {post['title']}
    내용 요약: {post['summary']}
    태그: {post['tags']}
    
    페르소나: {persona}
    당신은 이 글을 읽은 독자입니다. 자연스러운 댓글을 작성해주세요.
    너무 칭찬만 하지 말고, 질문이나 인사이트를 포함해주세요.
    """
    
    # Claude API call
    response = await claude_client.messages.create(...)
    return response.content[0].text
```

### Comment Bots (insung-blog pattern)

**Architecture:**
- `main.py`: Main comment bot runner
- `src/comment/commenter.py`: Comment generation logic
- `src/storage/supabase_client.py`: Comment tracking (pending, published)
- `command_worker.py`: Background task queue for comment jobs

**Workflow:**
1. **Target Selection**: Fetch recent posts from Naver Blog
2. **Context Gathering**: Extract title, tags, content preview
3. **Comment Generation**: AI → generate relevant comments
4. **Review**: Store in Supabase `pending_comments`
5. **Publishing**: User approval → post to Naver Blog
6. **Reply Tracking**: Monitor replies to bot comments

**Anti-Detection:**
- Rate limiting: 1 comment per N minutes
- Rotation: Multiple personas, varied comment length
- Natural language: Avoid repetitive patterns, use conversational tone

## Scheduling & Automation

### Cron Integration (Hermes)

**Setup:**
```bash
# Hermes TUI에서 설정
/cron create "every day at 10:00 AM"

# 프롬프트:
"""
매일 오전 10시에 /home/window11/insung_blog/scripts/daily_agent.py 실행
실행 결과를 텔레그램으로 보고
"""
```

**Agent Script Pattern:**
```python
#!/usr/bin/env python3
"""
Daily blog automation agent
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

async def main():
    # 1. Collect content
    # 2. Analyze & plan
    # 3. Generate draft
    # 4. Report to user
    # 5. Wait for approval
    # 6. Publish
    
    await report_to_telegram("Agent run complete")

if __name__ == "__main__":
    asyncio.run(main())
```

### Webhook Triggers

**Pattern:**
```python
# api_server.py
from fastapi import FastAPI

app = FastAPI()

@app.post("/webhook/photo-upload")
async def on_photo_upload(photo_url: str):
    # Trigger content pipeline
    plan = await analyze_photo(photo_url)
    draft = await generate_draft(plan)
    await save_for_review(draft)
```

**n8n Integration:**
- n8n HTTP Request node → FastAPI `/webhook/*` endpoints
- Workflow automation: n8n orchestrates, Hermes executes AI tasks

## Notification & Review

### Telegram Notifications

**Pattern:**
```python
# src/utils/telegram_notifier.py
from telegram import Bot

async def send_admin_notification(message: str):
    bot = Bot(token=os.environ["TELEGRAM_BOT_TOKEN"])
    chat_id = os.environ["TELEGRAM_ADMIN_CHAT_ID"]
    await bot.send_message(chat_id=chat_id, text=message)
```

**Approval Workflow:**
```python
# Send draft
await send_admin_notification(f"""
📝 New Draft Ready

Title: {draft['title']}
Preview: {draft['content'][:200]}...

Approve? /approve_{draft_id}
Reject? /reject_{draft_id}
""")

# Handle response (via Telegram bot or webhook)
if command == f"/approve_{draft_id}":
    await publish_draft(draft_id)
```

## Debugging & Troubleshooting

### Common Issues

**1. Login Expired**
- Symptom: Playwright redirects to login page
- Fix: Run `save_cookies.py` to refresh cookies
- Prevention: Schedule cookie refresh weekly

**2. DOM Selectors Changed**
- Symptom: `playwright` timeout errors, element not found
- Fix: Run debug scripts (e.g., `debug_publisher.py`, `debug_comment_selector.py`)
- Prevention: Monitor Naver Blog changes, run weekly smoke tests

**3. Rate Limiting**
- Symptom: Comments not posting, account flagged
- Fix: Increase delays between actions, use multiple accounts
- Prevention: Respect platform limits, vary timing

**4. API Token Issues**
- Symptom: 401 Unauthorized from Claude API
- Fix: Update `.env` with new API key
- Prevention: Rotate keys periodically

### Debug Scripts

**DOM Analysis:**
```python
# debug_publisher.py
from playwright.async_api import async_playwright

async def analyze_publish_page():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        
        await page.goto("https://blog.naver.com/post/write")
        
        # Print all buttons
        buttons = await page.locator("button").all()
        for btn in buttons:
            print(await btn.inner_text())
        
        # Print all inputs
        inputs = await page.locator("input").all()
        for inp in inputs:
            print(await inp.get_attribute("name") or await inp.get_attribute("id"))
```

**Comment Testing:**
```python
# test_my_blog.py
import pytest

@pytest.mark.asyncio
async def test_fetch_recent_posts():
    from src.naver.client import NaverClient
    client = NaverClient()
    posts = await client.fetch_recent_posts(count=5)
    assert len(posts) == 5
    assert all("title" in p for p in posts)
```

## Service Management (systemd)

**Pattern:**
```bash
# Status check
systemctl --user status blog-api blog-worker

# Restart
systemctl --user restart blog-api blog-worker

# Logs
journalctl --user -u blog-worker -n 50 --no-pager

# Multiple instance check (avoid conflicts)
ps aux | grep command_worker | grep -v grep | wc -l  # Should be 1
```

**Common Pitfalls:**
- **NEVER** `pkill -f command_worker.py` — systemd auto-restarts causing conflicts
- Use `systemctl --user stop blog-worker` instead
- Check for stale tmux sessions before restarting services

## Planning & Implementation

### Using writing-plans Skill

For complex blog automation features, always use `writing-plans` skill to create detailed implementation plans before coding.

**Pattern:**
1. Load `writing-plans` skill
2. Create plan with bite-sized tasks (2-5 min each)
3. Include exact file paths, complete code, verification steps
4. Execute via `subagent-driven-development` skill

**Example Plan Structure:**
```markdown
# [Feature Name] Implementation Plan

> For Hermes: Use subagent-driven-development skill to implement.

**Goal:** [One sentence]

**Architecture:** [2-3 sentences]

**Tech Stack:** [Key technologies]

---

### Task 1: [Descriptive Name]

**Objective:** What this task accomplishes

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `existing/file.py:45-67`

**Step 1: Write failing test**
[Code]

**Step 2: Run test**
[Command]
Expected: FAIL

**Step 3: Implement**
[Code]

**Step 4: Run test**
[Command]
Expected: PASS

**Step 5: Commit**
[Command]
```

## Best Practices

### Security

- **Never hardcode** API keys, passwords, or tokens in source code
- Use `.env` for secrets (gitignored)
- Rotate tokens regularly
- Use app-specific passwords where available (e.g., iCloud app passwords)
- Store cookies securely (encrypted if possible)

### Content Quality

- **Always review** AI-generated content before publishing
- Use persona tuning to match your voice
- A/B test different prompts for best results
- Track engagement metrics to refine strategy

### Platform Compliance

- **Respect rate limits** on all platforms
- Follow terms of service
- Don't spam — quality over quantity
- Use natural language patterns in automation
- Rotate timing to avoid detection

### Maintainability

- **Document all** platform-specific selectors (they change frequently)
- Keep debug scripts in `scripts/` for future troubleshooting
- Use type hints and async/await consistently
- Write tests for critical paths
- Commit frequently with descriptive messages

## Project Structure Template

```
blog-automation/
├── .env                      # Secrets (gitignored)
├── .env.example              # Template
├── CLAUDE.md                 # Project overview, rules
├── requirements.txt          # Python dependencies
├── main.py                   # Main bot runner
├── api_server.py             # FastAPI endpoints
├── command_worker.py         # Background queue worker
├── src/
│   ├── icloud/               # Photo collection
│   ├── content/              # AI generation
│   ├── naver/                # Naver Blog client
│   ├── storage/              # DB clients (Supabase, SQLite)
│   └── utils/                # Telegram, helpers
├── scripts/                  # Utility scripts
├── tests/                    # Pytest tests
├── cookies/                  # Browser cookies (gitignored)
├── logs/                     # Runtime logs
└── docs/
    └── plans/                # Implementation plans
```

## References & Templates

### Project-Specific Reference

**`references/naver-blog-automation.md`** — Detailed Naver Blog integration notes from the insung-blog project:
- Service architecture and management (systemd)
- Existing API endpoints (api_server.py, 1609 lines)
- Debug scripts for DOM analysis
- Cookie-based authentication and refresh procedures
- Supabase integration for control plane
- Telegram notification patterns
- Session start protocols and recovery procedures
- Common pitfalls and troubleshooting

**Use this reference when:**
- Working on Naver Blog automation
- Debugging selector issues
- Understanding the insung-blog project structure
- Setting up similar blog automation systems

### Starter Template

**`templates/daily-agent-script.py`** — Ready-to-use template for daily automation agents:
- Complete skeleton with collect → analyze → generate → report phases
- Telegram notification integration
- Error handling and logging
- Timeout management
- Placeholder TODO sections for customization

**How to use:**
```bash
# Copy to your project
cp ~/.hermes/skills/software-development/blog-automation/templates/daily-agent-script.py \
   /home/window11/your_project/scripts/your-agent.py

# Modify the TODO sections
# Update imports to match your project structure
# Add environment variables to .env

# Make executable
chmod +x /home/window11/your_project/scripts/your-agent.py

# Test
python /home/window11/your_project/scripts/your-agent.py

# Set up cron in Hermes
/cron create "every day at 10:00 AM"
# Then specify the script path
```
