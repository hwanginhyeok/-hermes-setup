---
name: codex
description: "Delegate coding to OpenAI Codex CLI (features, PRs)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, Codex, OpenAI, Code-Review, Refactoring]
    related_skills: [claude-code, hermes-agent]
---

# Codex CLI

Delegate coding tasks to [Codex](https://github.com/openai/codex) via the Hermes terminal. Codex is OpenAI's autonomous coding agent CLI.

## When to use

- Building features
- Refactoring
- PR reviews
- Batch issue fixing

Requires the codex CLI and a git repository.

## Prerequisites

- Codex installed: `npm install -g @openai/codex`
- OpenAI auth configured: either `OPENAI_API_KEY` or Codex OAuth credentials
  from the Codex CLI login flow
- **Must run inside a git repository** — Codex refuses to run outside one
- Use `pty=true` in terminal calls — Codex is an interactive terminal app

### Authentication Methods

**OAuth (Recommended):**
```bash
codex login --device-auth
# Follow browser authentication flow
```

**API Key:**
```bash
echo "sk-..." | codex login --with-api-key
```

**Access Token:**
```bash
echo "..." | codex login --with-access-token
```

**Verify authentication:**
```bash
codex login status
# Expected: "Logged in as <email>"
```

**Important notes (2026-06-01):**
- OAuth is sufficient - no API key required
- `~/.codex/` directory stores session and state data
- Check authentication status before running codex tasks
- If not logged in, Codex will prompt for authentication

## One-Shot Tasks

```
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)
```

For scratch work (Codex needs a git repo):
```
terminal(command="cd $(mktemp -d) && git init && codex exec 'Build a snake game in Python'", pty=true)
```

## Background Mode (Long Tasks)

```
# Start in background with PTY
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if Codex asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill if needed
process(action="kill", session_id="<id>")
```

## Key Flags

| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed but auto-approves file changes in workspace |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

## PR Reviews

Clone to a temp directory for safe review:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && gh pr checkout 42 && codex review --base origin/main", pty=true)
```

## Parallel Issue Fixing with Worktrees

```
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch Codex in each
terminal(command="codex --yolo exec 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="codex --yolo exec 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

## Batch PR Reviews

```
# Fetch all PR refs
terminal(command="git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'", workdir="~/project")

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)

# Post results
terminal(command="gh pr comment 86 --body '<review>'", workdir="~/project")
```

## Rules

1. **Always use `pty=true`** — Codex is an interactive terminal app and hangs without a PTY
2. **Git repo required** — Codex won't run outside a git directory. Use `mktemp -d && git init` for scratch
3. **Use `exec` for one-shots** — `codex exec "prompt"` runs and exits cleanly
4. **`--full-auto` for building** — auto-approves changes within the sandbox
5. **Background for long tasks** — use `background=true` and monitor with `process` tool
6. **Don't interfere** — monitor with `poll`/`log`, be patient with long-running tasks
7. **Parallel is fine** — run multiple Codex processes at once for batch work

## Pitfalls

### Authentication Persistence Issues

**Symptom:** `codex login --device-auth` completes successfully, but `codex login status` still shows "Not logged in"

**Cause:** OAuth session may not persist immediately or state files need refresh

**Solution:**
```bash
# Wait a few seconds after authentication
sleep 10 && codex login status

# Or check state files
ls -la ~/.codex/state_*.sqlite

# If still failing, try re-authentication
codex login --device-auth
# Follow browser flow again
codex login status
```

### Multi-LLM Review Integration Failures

**Symptom:** When using `delegate_task` with Codex + Claude + GLM for 3-person code review, all tasks fail with timeout/interrupt errors

**Cause:** 
- Each LLM CLI requires separate authentication (Codex OAuth, Claude login, GLM API)
- `delegate_task` may timeout waiting for child processes to complete
- Interactive CLI tools (like `codex exec`) don't work well with non-interactive delegation

**Failed Pattern:**
```python
delegate_task(tasks=[
    {"goal": "...", "acp_command": "codex", ...},  # ❌ Needs OAuth auth
    {"goal": "...", "model": "claude-opus-4-8", ...},  # ❌ Needs Claude auth
    {"goal": "...", "model": "glm-5.0", ...}  # ❌ Needs API access
])
```

**Solution Options:**
1. **Manual Sequential Testing** — Test each LLM CLI separately first:
   ```bash
   codex login --device-auth && codex login status
   claude --login
   # GLM: Check ~/.hermes/config.yaml for Z_AI_API_KEY
   ```

2. **Direct API Calls** — Skip CLI tools, call APIs directly:
   ```python
   import requests
   
   # GLM API example
   headers = {"Authorization": f"Bearer {os.getenv('Z_AI_API_KEY')}"}
   response = requests.post(
       "https://api.z.ai/v1/chat/completions",
       headers=headers,
       json={
           "model": "glm-5.0",
           "messages": [{"role": "user", "content": "Review this code..."}]
       }
   )
   ```

3. **Longer Timeout** — Increase delegate_task timeout:
   ```python
   delegate_task(tasks=[...], timeout=300)  # 5 minutes instead of default
   ```

4. **Simpler Test Cases** — Start with single-line code for quick validation:
   ```python
   # Instead of complex file review, start with:
   simple_code = "x = x + 1"
   test_review(prompt=f"Review this: {simple_code}")
   ```

### CLI Authentication Check Sequence

Before using any LLM CLI in automation, verify authentication:

```bash
# Codex
which codex && codex login status
# Expected: "Logged in as <email>"

# Claude
which claude && claude status
# Expected: Shows current login state

# GLM (via Hermes)
hermes status
# Check provider and model availability
```

**If any CLI shows "Not logged in":**
1. Run the authentication command for that CLI
2. Wait 10-15 seconds for state to sync
3. Verify with status command again
4. Only proceed to automation if all CLIs are authenticated
